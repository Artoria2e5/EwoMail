/*
   +----------------------------------------------------------------------+
   | Copyright (c) The PHP Group                                          |
   +----------------------------------------------------------------------+
   | This source file is subject to version 3.01 of the PHP license,      |
   | that is bundled with this package in the file LICENSE, and is        |
   | available through the world-wide-web at the following url:           |
   | https://www.php.net/license/3_01.txt                                 |
   | If you did not receive a copy of the PHP license and are unable to   |
   | obtain it through the world-wide-web, please send a note to          |
   | license@php.net so we can mail you a copy immediately.               |
   +----------------------------------------------------------------------+
   | Author: Stig Sæther Bakken <ssb@php.net>                             |
   +----------------------------------------------------------------------+
*/

#define CONFIGURE_COMMAND " './configure'  '--prefix=/ewomail/php72' '--with-config-file-path=/ewomail/php72/etc' '--with-fpm-user=www' '--with-fpm-group=www' '--enable-zip' '--enable-fpm' '--with-ldap' '--with-ldap-sasl' '--enable-bcmath' '--enable-pcntl' '--with-pdo_sqlite' '--with-gettext' '--with-iconv' '--enable-ftp' '--with-sqlite' '--with-sqlite3' '--enable-mbstring' '--enable-sockets' '--enable-soap' '--with-openssl' '--with-zlib' '--with-curl' '--with-gd' '--with-jpeg-dir' '--with-png-dir' '--with-freetype-dir' '--enable-xml' '--with-mhash' '--with-mysql=mysqlnd' '--with-mysqli=mysqlnd' '--with-pdo-mysql=mysqlnd' '--without-pear' '--with-libdir=lib64' '-C' '--enable-fpm-systemd'"
#define PHP_ODBC_CFLAGS	""
#define PHP_ODBC_LFLAGS		""
#define PHP_ODBC_LIBS		""
#define PHP_ODBC_TYPE		""
#define PHP_OCI8_DIR			""
#define PHP_OCI8_ORACLE_VERSION		""
#define PHP_PROG_SENDMAIL	"/usr/sbin/sendmail"
#define PEAR_INSTALLDIR         ""
#define PHP_INCLUDE_PATH	".:"
#define PHP_EXTENSION_DIR       "/ewomail/php72/lib/php/extensions/no-debug-non-zts-20230831"
#define PHP_PREFIX              "/ewomail/php72"
#define PHP_BINDIR              "/ewomail/php72/bin"
#define PHP_SBINDIR             "/ewomail/php72/sbin"
#define PHP_MANDIR              "/ewomail/php72/php/man"
#define PHP_LIBDIR              "/ewomail/php72/lib/php"
#define PHP_DATADIR             "/ewomail/php72/share/php"
#define PHP_SYSCONFDIR          "/ewomail/php72/etc"
#define PHP_LOCALSTATEDIR       "/ewomail/php72/var"
#define PHP_CONFIG_FILE_PATH    "/ewomail/php72/etc"
#define PHP_CONFIG_FILE_SCAN_DIR    ""
#define PHP_SHLIB_SUFFIX        "so"
#define PHP_SHLIB_EXT_PREFIX    ""
